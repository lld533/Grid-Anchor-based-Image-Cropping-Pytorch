import argparse
import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torch.autograd import Variable
import os, sys
import numpy as np


from nets.FullVggCompositionNet import FullVggCompositionNet as CompositionNet
from nets.SiameseNet import SiameseNet
from datasets import data_transforms
from pt_utils import cuda_model
import progressbar
from PIL import Image, ImageFilter


import glob

parser = argparse.ArgumentParser(description="Full VGG trained on CPC")
parser.add_argument('--l1', default=1024, type=int)
parser.add_argument('--l2', default=512, type=int)
parser.add_argument("--gpu_id", default='1', type=str)
parser.add_argument('--multiGpu', '-m', action='store_true', help='positivity constraint')
parser.add_argument('--resume', '-r', default='/home/lidali/image_crop/model/EvaluationNet.pth.tar', type=str, help='resume from checkpoint')


def get_test_list(root_path):
    return glob.glob(os.path.join(root_path, '**'))

if __name__ == '__main__':

    args = parser.parse_args()
    save_file = 'result_b16.txt'

    ckpt_file = args.resume
    if ckpt_file is not None:
        if not os.path.isfile(ckpt_file):
            print("CKPT {:s} NOT EXIST".format(ckpt_file))
            sys.exit(-1)
        print("load from {:s}".format(ckpt_file))

        single_pass_net = CompositionNet(pretrained=False, LinearSize1=args.l1, LinearSize2=args.l2)
        siamese_net = SiameseNet(single_pass_net)
        ckpt = torch.load(ckpt_file, map_location=lambda storage, loc: storage)
        model_state_dict = ckpt['state_dict']
        siamese_net.load_state_dict(model_state_dict)
    else:
        single_pass_net = CompositionNet(pretrained=True, LinearSize1=args.l1, LinearSize2=args.l2)
        siamese_net = SiameseNet(single_pass_net)
    

    useCuda = cuda_model.ifUseCuda(args.gpu_id, args.multiGpu)
    single_pass_net = cuda_model.convertModel2Cuda(single_pass_net, None, False)
    single_pass_net.eval()

    
    t_transform = data_transforms.get_val_transform(224)

    image_list = get_test_list('/home/lidali/image_crop/full_crops_b16')

    n_images = len(image_list)

    useCuda = False
    print("Number of Images:\t{:d}".format(len(image_list)))

    with open(save_file, 'wt+') as f:
        for image_idx, s_image_path in enumerate(image_list):
            image_crops = glob.glob(os.path.join(s_image_path, '*.jpg'))
            
            
            print("[{:d} | {:d}]\t{:s}".format(image_idx, n_images, os.path.basename(s_image_path)))
            pbar =progressbar.ProgressBar(max_value=len(image_crops))
            s_image_scores = []
            for crop_idx, s_image_crop in enumerate(image_crops):
                pbar.update(crop_idx)
                im = Image.open(s_image_crop)
                # @_@
                #im = im.filter(ImageFilter.GaussianBlur(radius=5))

                t_image_crop = t_transform(im)    
    
                if useCuda:
                    t_image_crop = t_image_crop.cuda()
    
                t_input = Variable(t_image_crop)
                t_output = single_pass_net(t_input.unsqueeze(0))
                score = t_output.data.cpu().numpy()[0][0]
                segs = os.path.basename(s_image_crop[:-4]).split('_')
                f.write('%s %s %f\n'%(segs[0], segs[1], score))
    
        print("Done Computing, results saved to {:s}".format(save_file))

