python3 demo.py --input="/home/lidali/image_crop/1_1" --output="1_1.txt"
python3 demo.py --input="/home/lidali/image_crop/4_3" --output="4_3.txt"
python3 demo.py --input="/home/lidali/image_crop/16_9" --output="16_9.txt"
